#include<stdio.h>
#include<conio.h>
void main(){
	int a[100],n,i;
	printf("Enter the size of the array:");
	scanf("%d",&n);
	printf("Enter the elements in array:");
	for(i=0;i<n;i++)
		scanf("%d\n",a[i]);
		printf("The array values are:");
		
	
for(i=0;i<n;i++)
printf("%d\n",a[i]);

}
