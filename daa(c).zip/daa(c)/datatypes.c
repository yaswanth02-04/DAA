#include<stdio.h>
#include<conio.h>
void main(){
	int a;
	float b;
	char c;
	char str[10];
	
	printf("Read the values");
	scanf("%d %c %f",&a,&c,&b);
	printf("the vauee of A %a\n The value of B=%b\n The value of C=%c\n",a,b,c);
}
